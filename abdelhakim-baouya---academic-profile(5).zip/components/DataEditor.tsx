import React, { useState } from 'react';
import { useProfileData } from '../profileDataContext';
import { ProfileDataSchema, Publication, Talk, TeachingExperience, Project, NewsItem, BiographyInterest, ProfileEmail } from '../types';

const DataEditor: React.FC = () => {
  const { data, updateData, resetData } = useProfileData();
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'forms' | 'raw'>('forms');
  const [formSubTab, setFormSubTab] = useState<'profile' | 'bio' | 'news' | 'pubs' | 'talks' | 'teaching' | 'projects' | 'activities'>('profile');
  
  // States for raw editing
  const [rawJson, setRawJson] = useState(JSON.stringify(data, null, 2));
  const [jsonError, setJsonError] = useState<string | null>(null);

  // Synchronize raw JSON state when data changes or panel opens
  const handleOpen = () => {
    setRawJson(JSON.stringify(data, null, 2));
    setJsonError(null);
    setIsOpen(true);
  };

  const handleRawJsonChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setRawJson(val);
    try {
      const parsed = JSON.parse(val);
      // Basic verification that root keys exist
      const requiredKeys: (keyof ProfileDataSchema)[] = ['profile', 'biography', 'news', 'publications', 'talks', 'teaching', 'projects', 'activities', 'interviews'];
      const missing = requiredKeys.filter(k => !(k in parsed));
      if (missing.length > 0) {
        setJsonError(`Valid JSON structure, but missing root properties: ${missing.join(', ')}`);
      } else {
        setJsonError(null);
      }
    } catch (err: any) {
      setJsonError(`Invalid JSON format: ${err.message}`);
    }
  };

  const saveRawJson = () => {
    if (jsonError) return;
    try {
      const parsed = JSON.parse(rawJson);
      updateData(parsed);
      alert('Content applied successfully!');
    } catch (err: any) {
      setJsonError(`Failed to save: ${err.message}`);
    }
  };

  const downloadJson = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'data.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Profile fields editing helper
  const handleProfileFieldChange = (key: string, value: any) => {
    const updated = {
      ...data,
      profile: {
        ...data.profile,
        [key]: value
      }
    };
    updateData(updated);
  };

  // Biography fields editing helper
  const handleBioFieldChange = (key: keyof typeof data.biography, value: any) => {
    const updated = {
      ...data,
      biography: {
        ...data.biography,
        [key]: value
      }
    };
    updateData(updated);
  };

  return (
    <>
      {/* Floating Control Button */}
      <button
        onClick={handleOpen}
        className="fixed bottom-6 right-6 z-40 bg-primary hover:bg-blue-700 text-white font-semibold py-3 px-5 rounded-full shadow-2xl shadow-primary/40 flex items-center gap-2 transform hover:scale-105 transition-all duration-300 group"
        title="Admin Panel: Edit academic data"
      >
        <i className="fas fa-edit animate-pulse"></i>
        <span>Edit Profile Data</span>
        <span className="bg-white/20 text-[10px] px-1.5 py-0.5 rounded uppercase font-bold tracking-wider group-hover:bg-white/35 transition-colors">JSON</span>
      </button>

      {/* Slide-over Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden" aria-modal="true" role="dialog">
          <div className="absolute inset-0 overflow-hidden">
            {/* Background backdrop */}
            <div 
              className="absolute inset-0 bg-slate-900/60 transition-opacity backdrop-blur-sm"
              onClick={() => setIsOpen(false)}
            />

            {/* Panel */}
            <div className="absolute inset-y-0 right-0 max-w-3xl w-full pl-10 flex">
              <div className="w-full flex flex-col bg-white shadow-2xl border-l border-slate-200">
                {/* Header */}
                <div className="px-6 py-5 bg-gradient-to-r from-slate-900 to-slate-800 text-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center text-primary text-lg">
                        <i className="fas fa-cog text-blue-400"></i>
                      </div>
                      <div>
                        <h2 className="text-lg font-bold">Academic Content Manager</h2>
                        <p className="text-xs text-slate-300">Update content and generate your updated code JSON</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setIsOpen(false)}
                      className="text-slate-400 hover:text-white transition-colors"
                    >
                      <i className="fas fa-times text-xl"></i>
                    </button>
                  </div>

                  {/* Top-level Tabs */}
                  <div className="flex gap-4 border-t border-slate-700/80 pt-4 mt-4">
                    <button
                      onClick={() => setActiveTab('forms')}
                      className={`flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-lg transition-all ${
                        activeTab === 'forms' 
                          ? 'bg-primary text-white shadow-lg' 
                          : 'text-slate-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <i className="fas fa-list-check"></i> Form Editor
                    </button>
                    <button
                      onClick={() => {
                        setActiveTab('raw');
                        setRawJson(JSON.stringify(data, null, 2));
                      }}
                      className={`flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-lg transition-all ${
                        activeTab === 'raw' 
                          ? 'bg-primary text-white shadow-lg' 
                          : 'text-slate-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <i className="fas fa-code"></i> Raw JSON Database
                    </button>
                  </div>
                </div>

                {/* Sub-Actions Toolbar */}
                <div className="px-6 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap gap-2 items-center justify-between text-xs">
                  <div className="flex gap-2">
                    <button
                      onClick={downloadJson}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-1.5 px-3 rounded flex items-center gap-1.5 transition-colors shadow-sm"
                      title="Generate and download data.json to paste in your workspace root directory"
                    >
                      <i className="fas fa-download"></i> Download data.json
                    </button>
                    <button
                      onClick={() => {
                        if (confirm('Revert all adjustments and restore original academic information?')) {
                          resetData();
                        }
                      }}
                      className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold py-1.5 px-3 rounded flex items-center gap-1.5 transition-colors"
                    >
                      <i className="fas fa-undo"></i> Reset to Default
                    </button>
                  </div>
                  <span className="text-slate-400 italic font-mono uppercase tracking-wider text-[10px]">Active persistence enabled</span>
                </div>

                {/* Content Workspace */}
                <div className="flex-grow overflow-y-auto p-6 bg-slate-100">
                  {activeTab === 'forms' ? (
                    <div className="flex flex-col md:flex-row gap-6 h-full min-h-[400px]">
                      {/* Form categories list */}
                      <ul className="w-full md:w-48 flex-shrink-0 flex md:flex-col gap-1 overflow-x-auto md:overflow-x-visible pb-2 md:pb-0 font-sans text-xs font-semibold text-slate-600">
                        {(['profile', 'bio', 'news', 'pubs', 'talks', 'teaching', 'projects', 'activities'] as const).map((tab) => (
                          <li key={tab} className="w-full">
                            <button
                              onClick={() => setFormSubTab(tab)}
                              className={`w-full text-left px-3 py-2.5 rounded-lg transition-colors flex items-center gap-2 ${
                                formSubTab === tab 
                                  ? 'bg-white text-primary font-bold shadow-sm border-l-4 border-primary' 
                                  : 'hover:bg-slate-200 text-slate-600'
                              }`}
                            >
                              <i className={`fas ${
                                tab === 'profile' ? 'fa-id-card' :
                                tab === 'bio' ? 'fa-user' :
                                tab === 'news' ? 'fa-newspaper' :
                                tab === 'pubs' ? 'fa-bookmark' :
                                tab === 'talks' ? 'fa-comments' :
                                tab === 'teaching' ? 'fa-chalkboard-user' :
                                tab === 'projects' ? 'fa-diagram-project' : 'fa-briefcase'
                              } w-4 text-center ${formSubTab === tab ? 'text-primary' : 'text-slate-400'}`}></i>
                              <span className="capitalize">{tab === 'pubs' ? 'Publications' : tab}</span>
                            </button>
                          </li>
                        ))}
                      </ul>

                      {/* Editing Forms */}
                      <div className="flex-grow bg-white rounded-xl shadow-sm border border-slate-200 p-6 overflow-y-auto max-h-[60vh] md:max-h-none">
                        {formSubTab === 'profile' && (
                          <div className="space-y-4">
                            <h3 className="font-bold text-slate-800 border-b pb-2 mb-4 text-sm uppercase">General Settings</h3>
                            <div>
                              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Dr. Full Name</label>
                              <input 
                                type="text" 
                                value={data.profile.name}
                                onChange={(e) => handleProfileFieldChange('name', e.target.value)}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-primary"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Academic Title</label>
                              <input 
                                type="text" 
                                value={data.profile.title}
                                onChange={(e) => handleProfileFieldChange('title', e.target.value)}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-primary"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Location Details</label>
                              <textarea 
                                value={data.profile.location}
                                onChange={(e) => handleProfileFieldChange('location', e.target.value)}
                                rows={2}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-primary font-mono"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Primary Contacts</label>
                              {data.profile.emails.map((emailObj, idx) => (
                                <div key={idx} className="flex gap-2 mb-2 items-center">
                                  <input 
                                    type="text" 
                                    placeholder="Label" 
                                    value={emailObj.title}
                                    onChange={(e) => {
                                      const newEmails = [...data.profile.emails];
                                      newEmails[idx].title = e.target.value;
                                      handleProfileFieldChange('emails', newEmails);
                                    }}
                                    className="w-1/3 border border-slate-300 rounded-lg px-2 py-1.5 text-xs focus:outline-primary font-semibold"
                                  />
                                  <input 
                                    type="email" 
                                    placeholder="Email Address"
                                    value={emailObj.email}
                                    onChange={(e) => {
                                      const newEmails = [...data.profile.emails];
                                      newEmails[idx].email = e.target.value;
                                      handleProfileFieldChange('emails', newEmails);
                                    }}
                                    className="w-2/3 border border-slate-300 rounded-lg px-2 py-1.5 text-xs focus:outline-primary font-mono"
                                  />
                                </div>
                              ))}
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Social Networks</label>
                              <div className="grid grid-cols-1 gap-2">
                                {Object.keys(data.profile.socials).map((socialKey) => (
                                  <div key={socialKey} className="flex items-center gap-2">
                                    <span className="w-24 text-xs font-semibold text-slate-600 capitalize">{socialKey}:</span>
                                    <input 
                                      type="text" 
                                      value={(data.profile.socials as any)[socialKey]}
                                      onChange={(e) => {
                                        const updatedSocials = {
                                          ...data.profile.socials,
                                          [socialKey]: e.target.value
                                        };
                                        handleProfileFieldChange('socials', updatedSocials);
                                      }}
                                      className="flex-grow border border-slate-300 rounded-lg px-2 py-1.5 text-xs focus:outline-primary font-mono"
                                    />
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}

                        {formSubTab === 'bio' && (
                          <div className="space-y-4">
                            <h3 className="font-bold text-slate-800 border-b pb-2 mb-4 text-sm uppercase">Biography Details</h3>
                            <div>
                              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Biography Paragraphs</label>
                              {data.biography.paragraphs.map((para, idx) => (
                                <div key={idx} className="mb-3 relative group">
                                  <span className="absolute -left-3 top-2 text-[10px] font-bold text-slate-400 bg-slate-200 px-1 rounded">P{idx+1}</span>
                                  <textarea 
                                    value={para}
                                    onChange={(e) => {
                                      const newParas = [...data.biography.paragraphs];
                                      newParas[idx] = e.target.value;
                                      handleBioFieldChange('paragraphs', newParas);
                                    }}
                                    rows={3}
                                    className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-primary"
                                  />
                                </div>
                              ))}
                            </div>
                            <div>
                              <div className="flex items-center justify-between mb-2">
                                <label className="block text-xs font-bold text-slate-500 uppercase">Beyond Research Interests</label>
                                <button
                                  type="button"
                                  onClick={() => {
                                    const newInterests = [...data.biography.interests, { name: 'New interest', icon: 'fas fa-star' }];
                                    handleBioFieldChange('interests', newInterests);
                                  }}
                                  className="text-[10px] bg-primary text-white font-bold py-1 px-2 rounded hover:bg-blue-600"
                                >
                                  + Add Item
                                </button>
                              </div>
                              <div className="space-y-2">
                                {data.biography.interests.map((interest, idx) => (
                                  <div key={idx} className="flex gap-2 items-center bg-slate-50 p-2 rounded-lg border">
                                    <span className="text-slate-400 text-xs"><i className={interest.icon || 'fas fa-star'}></i></span>
                                    <input 
                                      type="text" 
                                      placeholder="Icon (e.g., fas fa-hiking)" 
                                      value={interest.icon}
                                      onChange={(e) => {
                                        const newInterests = [...data.biography.interests];
                                        newInterests[idx].icon = e.target.value;
                                        handleBioFieldChange('interests', newInterests);
                                      }}
                                      className="w-1/3 border border-slate-300 rounded px-2 py-1 text-xs font-mono"
                                    />
                                    <input 
                                      type="text" 
                                      placeholder="Name" 
                                      value={interest.name}
                                      onChange={(e) => {
                                        const newInterests = [...data.biography.interests];
                                        newInterests[idx].name = e.target.value;
                                        handleBioFieldChange('interests', newInterests);
                                      }}
                                      className="flex-grow border border-slate-300 rounded px-2 py-1 text-xs"
                                    />
                                    <button 
                                      className="text-red-500 hover:text-red-700"
                                      onClick={() => {
                                        const newInterests = data.biography.interests.filter((_, i) => i !== idx);
                                        handleBioFieldChange('interests', newInterests);
                                      }}
                                    >
                                      <i className="fas fa-trash-can text-xs"></i>
                                    </button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                      )}

                        {formSubTab === 'news' && (
                          <div className="space-y-4">
                            <div className="flex items-center justify-between border-b pb-2 mb-4">
                              <h3 className="font-bold text-slate-800 text-sm uppercase">Latest News highlights</h3>
                              <button
                                type="button"
                                onClick={() => {
                                  const updated = {
                                    ...data,
                                    news: [
                                      { month: 'Jun', year: '2026', text: 'New academic update details' },
                                      ...data.news
                                    ]
                                  };
                                  updateData(updated);
                                }}
                                className="text-[10px] bg-emerald-600 text-white font-bold py-1 px-2.5 rounded hover:bg-emerald-700 shadow-sm"
                              >
                                + Add News Item
                              </button>
                            </div>
                            <div className="space-y-3">
                              {data.news.map((item, idx) => (
                                <div key={idx} className="bg-slate-50 border rounded-xl p-4 relative group hover:border-slate-300">
                                  <button
                                    onClick={() => {
                                      const updatedNews = data.news.filter((_, i) => i !== idx);
                                      updateData({ ...data, news: updatedNews });
                                    }}
                                    className="absolute top-2 right-2 text-red-400 hover:text-red-600 transition-colors"
                                    title="Delete update"
                                  >
                                    <i className="fas fa-trash-can text-sm"></i>
                                  </button>
                                  <div className="grid grid-cols-2 gap-2 mb-2">
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Month</label>
                                      <input 
                                        type="text" 
                                        value={item.month}
                                        onChange={(e) => {
                                          const newNews = [...data.news];
                                          newNews[idx].month = e.target.value;
                                          updateData({ ...data, news: newNews });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Year</label>
                                      <input 
                                        type="text" 
                                        value={item.year}
                                        onChange={(e) => {
                                          const newNews = [...data.news];
                                          newNews[idx].year = e.target.value;
                                          updateData({ ...data, news: newNews });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                      />
                                    </div>
                                  </div>
                                  <div className="mb-2">
                                    <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Content text</label>
                                    <textarea 
                                      value={item.text}
                                      onChange={(e) => {
                                        const newNews = [...data.news];
                                        newNews[idx].text = e.target.value;
                                        updateData({ ...data, news: newNews });
                                      }}
                                      rows={2}
                                      className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                    />
                                  </div>
                                  <div className="grid grid-cols-2 gap-2">
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Affiliated Link</label>
                                      <input 
                                        type="text" 
                                        placeholder="Optional URL" 
                                        value={item.link || ''}
                                        onChange={(e) => {
                                          const newNews = [...data.news];
                                          newNews[idx].link = e.target.value;
                                          updateData({ ...data, news: newNews });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs font-mono"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Link Text</label>
                                      <input 
                                        type="text" 
                                        placeholder="Optional Label" 
                                        value={item.linkText || ''}
                                        onChange={(e) => {
                                          const newNews = [...data.news];
                                          newNews[idx].linkText = e.target.value;
                                          updateData({ ...data, news: newNews });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                      />
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                      )}

                        {formSubTab === 'pubs' && (
                          <div className="space-y-4">
                            <div className="flex items-center justify-between border-b pb-2 mb-4">
                              <h3 className="font-bold text-slate-800 text-sm uppercase">Publications list</h3>
                              <button
                                type="button"
                                onClick={() => {
                                  const newPub: Publication = {
                                    id: `j_new_${Date.now()}`,
                                    title: 'A New Scientific Breakthrough Paper',
                                    authors: 'Abdelhakim Baouya',
                                    venue: 'IEEE Transactions',
                                    date: '2026',
                                    type: 'Journal'
                                  };
                                  updateData({
                                    ...data,
                                    publications: [newPub, ...data.publications]
                                  });
                                }}
                                className="text-[10px] bg-emerald-600 text-white font-bold py-1 px-2.5 rounded hover:bg-emerald-700 shadow-sm"
                              >
                                + Add Publication
                              </button>
                            </div>
                            <div className="space-y-4">
                              {data.publications.map((pub, idx) => (
                                <div key={pub.id} className="bg-slate-50 border rounded-xl p-4 relative group hover:border-slate-300">
                                  <button
                                    onClick={() => {
                                      const updatedPubs = data.publications.filter(p => p.id !== pub.id);
                                      updateData({ ...data, publications: updatedPubs });
                                    }}
                                    className="absolute top-2 right-2 text-red-400 hover:text-red-600 transition-colors"
                                  >
                                    <i className="fas fa-trash-can text-sm"></i>
                                  </button>
                                  <div className="grid grid-cols-3 gap-2 mb-2">
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Id</label>
                                      <input 
                                        type="text" 
                                        value={pub.id}
                                        onChange={(e) => {
                                          const newPubs = [...data.publications];
                                          newPubs[idx].id = e.target.value;
                                          updateData({ ...data, publications: newPubs });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs font-mono"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Type</label>
                                      <select 
                                        value={pub.type} 
                                        onChange={(e) => {
                                          const newPubs = [...data.publications];
                                          newPubs[idx].type = e.target.value as any;
                                          updateData({ ...data, publications: newPubs });
                                        }}
                                        className="w-full border border-slate-300 bg-white rounded px-2 py-1 text-xs"
                                      >
                                        <option value="Journal">Journal</option>
                                        <option value="Conference">Conference</option>
                                        <option value="Workshop">Workshop</option>
                                        <option value="Thesis">Thesis</option>
                                      </select>
                                    </div>
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Date</label>
                                      <input 
                                        type="text" 
                                        value={pub.date}
                                        onChange={(e) => {
                                          const newPubs = [...data.publications];
                                          newPubs[idx].date = e.target.value;
                                          updateData({ ...data, publications: newPubs });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                      />
                                    </div>
                                  </div>
                                  <div className="mb-2">
                                    <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Title</label>
                                    <input 
                                      type="text" 
                                      value={pub.title}
                                      onChange={(e) => {
                                        const newPubs = [...data.publications];
                                        newPubs[idx].title = e.target.value;
                                        updateData({ ...data, publications: newPubs });
                                      }}
                                      className="w-full border border-slate-300 rounded px-2 py-1 text-xs font-bold"
                                    />
                                  </div>
                                  <div className="mb-2">
                                    <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Authors</label>
                                    <input 
                                      type="text" 
                                      value={pub.authors}
                                      onChange={(e) => {
                                        const newPubs = [...data.publications];
                                        newPubs[idx].authors = e.target.value;
                                        updateData({ ...data, publications: newPubs });
                                      }}
                                      className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Venue</label>
                                    <input 
                                      type="text" 
                                      value={pub.venue}
                                      onChange={(e) => {
                                        const newPubs = [...data.publications];
                                        newPubs[idx].venue = e.target.value;
                                        updateData({ ...data, publications: newPubs });
                                      }}
                                      className="w-full border border-slate-300 rounded px-2 py-1 text-xs italic"
                                    />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                      )}

                        {formSubTab === 'talks' && (
                          <div className="space-y-4">
                            <div className="flex items-center justify-between border-b pb-2 mb-4">
                              <h3 className="font-bold text-slate-800 text-sm uppercase">Invited Talks</h3>
                              <button
                                type="button"
                                onClick={() => {
                                  const newTalk: Talk = {
                                    id: `t_${Date.now()}`,
                                    title: 'New Invited Keynote Seminar',
                                    event: 'Academic Guest Lecture',
                                    location: 'IRIT, Toulouse, France',
                                    date: 'September 2026'
                                  };
                                  updateData({
                                    ...data,
                                    talks: [newTalk, ...data.talks]
                                  });
                                }}
                                className="text-[10px] bg-emerald-600 text-white font-bold py-1 px-2.5 rounded hover:bg-emerald-700 shadow-sm"
                              >
                                + Add Invited Talk
                              </button>
                            </div>
                            <div className="space-y-4">
                              {data.talks.map((talk, idx) => (
                                <div key={talk.id} className="bg-slate-50 border rounded-xl p-4 relative group hover:border-slate-300">
                                  <button
                                    onClick={() => {
                                      const updatedTalks = data.talks.filter(t => t.id !== talk.id);
                                      updateData({ ...data, talks: updatedTalks });
                                    }}
                                    className="absolute top-2 right-2 text-red-400 hover:text-red-600 transition-colors"
                                  >
                                    <i className="fas fa-trash-can text-sm"></i>
                                  </button>
                                  <div className="grid grid-cols-2 gap-2 mb-2">
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Date</label>
                                      <input 
                                        type="text" 
                                        value={talk.date}
                                        onChange={(e) => {
                                          const nt = [...data.talks];
                                          nt[idx].date = e.target.value;
                                          updateData({ ...data, talks: nt });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Event Type</label>
                                      <input 
                                        type="text" 
                                        value={talk.event}
                                        onChange={(e) => {
                                          const nt = [...data.talks];
                                          nt[idx].event = e.target.value;
                                          updateData({ ...data, talks: nt });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                      />
                                    </div>
                                  </div>
                                  <div className="mb-2">
                                    <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Title</label>
                                    <input 
                                      type="text" 
                                      value={talk.title}
                                      onChange={(e) => {
                                        const nt = [...data.talks];
                                        nt[idx].title = e.target.value;
                                        updateData({ ...data, talks: nt });
                                      }}
                                      className="w-full border border-slate-300 rounded px-2 py-1 text-xs font-bold"
                                    />
                                  </div>
                                  <div className="mb-2">
                                    <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Location</label>
                                    <input 
                                      type="text" 
                                      value={talk.location}
                                      onChange={(e) => {
                                        const nt = [...data.talks];
                                        nt[idx].location = e.target.value;
                                        updateData({ ...data, talks: nt });
                                      }}
                                      className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                    />
                                  </div>
                                  <div>
                                    <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Notes (Optional)</label>
                                    <input 
                                      type="text" 
                                      placeholder="Extra details"
                                      value={talk.note || ''}
                                      onChange={(e) => {
                                        const nt = [...data.talks];
                                        nt[idx].note = e.target.value;
                                        updateData({ ...data, talks: nt });
                                      }}
                                      className="w-full border border-slate-300 rounded px-2 py-1 text-xs italic"
                                    />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                      )}

                        {formSubTab === 'teaching' && (
                          <div className="space-y-4">
                            <h3 className="font-bold text-slate-800 border-b pb-2 mb-4 text-sm uppercase">Teaching Positions</h3>
                            <div className="space-y-4">
                              {data.teaching.map((experience, idx) => (
                                <div key={idx} className="bg-slate-50 border rounded-xl p-4">
                                  <div className="grid grid-cols-2 gap-2 mb-2">
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">institution</label>
                                      <input 
                                        type="text" 
                                        value={experience.institution}
                                        onChange={(e) => {
                                          const t = [...data.teaching];
                                          t[idx].institution = e.target.value;
                                          updateData({ ...data, teaching: t });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs font-bold"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">role / Period</label>
                                      <input 
                                        type="text" 
                                        value={experience.role}
                                        onChange={(e) => {
                                          const t = [...data.teaching];
                                          t[idx].role = e.target.value;
                                          updateData({ ...data, teaching: t });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                      />
                                    </div>
                                  </div>

                                  {/* Inner Courses List */}
                                  <div>
                                    <div className="flex justify-between items-center mb-1">
                                      <span className="text-[10px] font-bold text-slate-500 uppercase">Courses List</span>
                                      <button
                                        type="button"
                                        onClick={() => {
                                          const t = [...data.teaching];
                                          t[idx].courses.push({ name: 'New Course Title', level: 'M1' });
                                          updateData({ ...data, teaching: t });
                                        }}
                                        className="text-[9px] bg-primary text-white font-bold px-1.5 py-0.5 rounded"
                                      >
                                        + Add Course
                                      </button>
                                    </div>
                                    <div className="space-y-1">
                                      {experience.courses.map((course, cIdx) => (
                                        <div key={cIdx} className="flex gap-1.5 items-center">
                                          <input 
                                            type="text" 
                                            placeholder="Level" 
                                            value={course.level}
                                            onChange={(e) => {
                                              const t = [...data.teaching];
                                              t[idx].courses[cIdx].level = e.target.value;
                                              updateData({ ...data, teaching: t });
                                            }}
                                            className="w-16 border rounded px-1.5 py-0.5 text-[11px]"
                                          />
                                          <input 
                                            type="text" 
                                            placeholder="Course Name" 
                                            value={course.name}
                                            onChange={(e) => {
                                              const t = [...data.teaching];
                                              t[idx].courses[cIdx].name = e.target.value;
                                              updateData({ ...data, teaching: t });
                                            }}
                                            className="flex-grow border rounded px-1.5 py-0.5 text-[11px]"
                                          />
                                          <button
                                            type="button"
                                            onClick={() => {
                                              const t = [...data.teaching];
                                              t[idx].courses = t[idx].courses.filter((_, cI) => cI !== cIdx);
                                              updateData({ ...data, teaching: t });
                                            }}
                                            className="text-red-500 text-xs hover:text-red-700 font-bold px-1"
                                          >
                                            &times;
                                          </button>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                      )}

                        {formSubTab === 'projects' && (
                          <div className="space-y-4">
                            <div className="flex items-center justify-between border-b pb-2 mb-4">
                              <h3 className="font-bold text-slate-800 text-sm uppercase">Grants & Projects</h3>
                              <button
                                type="button"
                                onClick={() => {
                                  const newProj: Project = {
                                    id: `p_${Date.now()}`,
                                    name: 'New Research Grant',
                                    description: 'Project details and structural aims.',
                                    duration: '2026 - 2028',
                                    role: 'Leader'
                                  };
                                  updateData({ ...data, projects: [...data.projects, newProj] });
                                }}
                                className="text-[10px] bg-emerald-600 text-white font-bold py-1 px-2.5 rounded hover:bg-emerald-700 shadow-sm"
                              >
                                + Add Project
                              </button>
                            </div>
                            <div className="space-y-4">
                              {data.projects.map((proj, idx) => (
                                <div key={proj.id} className="bg-slate-50 border rounded-xl p-4 relative group hover:border-slate-300">
                                  <button
                                    onClick={() => {
                                      const updatedPr = data.projects.filter(p => p.id !== proj.id);
                                      updateData({ ...data, projects: updatedPr });
                                    }}
                                    className="absolute top-2 right-2 text-red-400 hover:text-red-600 transition-colors"
                                  >
                                    <i className="fas fa-trash-can text-sm"></i>
                                  </button>
                                  <div className="grid grid-cols-3 gap-2 mb-2">
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Project Name</label>
                                      <input 
                                        type="text" 
                                        value={proj.name}
                                        onChange={(e) => {
                                          const pr = [...data.projects];
                                          pr[idx].name = e.target.value;
                                          updateData({ ...data, projects: pr });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs font-bold"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Duration</label>
                                      <input 
                                        type="text" 
                                        value={proj.duration}
                                        onChange={(e) => {
                                          const pr = [...data.projects];
                                          pr[idx].duration = e.target.value;
                                          updateData({ ...data, projects: pr });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Role / Leader</label>
                                      <input 
                                        type="text" 
                                        value={proj.role || ''}
                                        onChange={(e) => {
                                          const pr = [...data.projects];
                                          pr[idx].role = e.target.value;
                                          updateData({ ...data, projects: pr });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                      />
                                    </div>
                                  </div>
                                  <div className="mb-2">
                                    <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Focus description</label>
                                    <textarea 
                                      value={proj.description}
                                      onChange={(e) => {
                                        const pr = [...data.projects];
                                        pr[idx].description = e.target.value;
                                        updateData({ ...data, projects: pr });
                                      }}
                                      rows={2}
                                      className="w-full border border-slate-300 rounded px-2 py-1 text-xs"
                                    />
                                  </div>
                                  <div className="grid grid-cols-2 gap-2">
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Funding (Optional)</label>
                                      <input 
                                        type="text" 
                                        placeholder="e.g., 20 k€" 
                                        value={proj.funding || ''}
                                        onChange={(e) => {
                                          const pr = [...data.projects];
                                          pr[idx].funding = e.target.value;
                                          updateData({ ...data, projects: pr });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs font-medium"
                                      />
                                    </div>
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 mb-0.5">Project Web Link (Optional)</label>
                                      <input 
                                        type="text" 
                                        placeholder="https://..." 
                                        value={proj.url || ''}
                                        onChange={(e) => {
                                          const pr = [...data.projects];
                                          pr[idx].url = e.target.value;
                                          updateData({ ...data, projects: pr });
                                        }}
                                        className="w-full border border-slate-300 rounded px-2 py-1 text-xs font-mono"
                                      />
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                      )}

                        {formSubTab === 'activities' && (
                          <div className="space-y-4">
                            <h3 className="font-bold text-slate-800 border-b pb-2 mb-4 text-sm uppercase">Committees & Review Activities</h3>
                            
                            <div>
                              <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Symposium & Committees title</label>
                              <input 
                                type="text"
                                value={data.activities.title}
                                onChange={(e) => {
                                  updateData({
                                    ...data,
                                    activities: {
                                      ...data.activities,
                                      title: e.target.value
                                    }
                                  });
                                }}
                                className="w-full border border-slate-300 rounded-lg px-3 py-2 text-xs focus:outline-primary mb-4"
                              />
                            </div>

                            {/* Committees list */}
                            <div>
                              <div className="flex justify-between items-center mb-1">
                                <span className="text-xs font-bold text-slate-500 uppercase">Committees Seats</span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    const actCopy = { ...data.activities };
                                    actCopy.items.unshift({ role: 'Member', details: ['New Committee Seat (2026)'], icon: 'fas fa-star' });
                                    updateData({ ...data, activities: actCopy });
                                  }}
                                  className="text-[10px] bg-primary text-white font-bold py-1 px-2 rounded"
                                >
                                  + Add Committee
                                </button>
                              </div>
                              <div className="space-y-3">
                                {data.activities.items.map((item, idx) => (
                                  <div key={idx} className="bg-slate-50 border rounded-lg p-3 relative group">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const actCopy = { ...data.activities };
                                        actCopy.items = actCopy.items.filter((_, i) => i !== idx);
                                        updateData({ ...data, activities: actCopy });
                                      }}
                                      className="absolute top-2 right-2 text-red-500 hover:text-red-700"
                                    >
                                      &times;
                                    </button>
                                    <div className="grid grid-cols-2 gap-2 mb-2">
                                      <div>
                                        <input 
                                          type="text" 
                                          placeholder="Role" 
                                          value={item.role}
                                          onChange={(e) => {
                                            const actCopy = { ...data.activities };
                                            actCopy.items[idx].role = e.target.value;
                                            updateData({ ...data, activities: actCopy });
                                          }}
                                          className="w-full border rounded text-xs px-2 py-0.5 font-bold"
                                        />
                                      </div>
                                      <div>
                                        <input 
                                          type="text" 
                                          placeholder="Icon CSS" 
                                          value={item.icon}
                                          onChange={(e) => {
                                            const actCopy = { ...data.activities };
                                            actCopy.items[idx].icon = e.target.value;
                                            updateData({ ...data, activities: actCopy });
                                          }}
                                          className="w-full border rounded text-xs px-2 py-0.5 font-mono"
                                        />
                                      </div>
                                    </div>
                                    <div>
                                      <label className="block text-[10px] font-bold text-slate-400 capitalize mb-0.5">Details (Comma-separated)</label>
                                      <textarea 
                                        placeholder="Toulouse Conference, SCPS Symposium, CIIA Seminar" 
                                        value={item.details.join('\n')}
                                        onChange={(e) => {
                                          const actCopy = { ...data.activities };
                                          actCopy.items[idx].details = e.target.value.split('\n').filter(Boolean);
                                          updateData({ ...data, activities: actCopy });
                                        }}
                                        rows={2}
                                        className="w-full border rounded text-xs px-2 py-1 font-sans"
                                      />
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                      )}
                      </div>
                    </div>
                  ) : (
                    /* Raw JSON Editor with Syntax Feedback */
                    <div className="flex flex-col h-full gap-4">
                      <div className="bg-slate-900 rounded-xl p-4 flex-grow flex flex-col font-mono text-xs border border-slate-700 shadow-inner">
                        <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2 mb-2">
                          <span>data.json Editor</span>
                          <span className="text-[10px] bg-white/10 px-1.5 py-0.5 rounded text-white font-bold tracking-wider uppercase">Active View</span>
                        </div>
                        <textarea
                          value={rawJson}
                          onChange={handleRawJsonChange}
                          rows={22}
                          className="w-full flex-grow bg-transparent text-emerald-400 focus:outline-none resize-none font-mono text-xs leading-relaxed overflow-y-auto"
                          placeholder="Paste data.json content here..."
                        />
                      </div>
                      
                      {jsonError ? (
                        <div className="bg-red-50 text-red-600 px-4 py-3 rounded-xl border border-red-100 flex items-start gap-2.5 text-xs font-sans shadow-sm">
                          <i className="fas fa-triangle-exclamation text-base mt-0.5 flex-shrink-0"></i>
                          <div>
                            <p className="font-bold">Errors Found</p>
                            <p>{jsonError}</p>
                          </div>
                        </div>
                      ) : (
                        <div className="bg-emerald-50 text-emerald-700 px-4 py-3 rounded-xl border border-emerald-100 flex items-center gap-2.5 text-xs font-sans shadow-sm">
                          <i className="fas fa-circle-check text-base"></i>
                          <p className="font-bold">JSON Structure is fully valid and compliant!</p>
                        </div>
                      )}

                      <button
                        onClick={saveRawJson}
                        disabled={!!jsonError}
                        className={`w-full py-3 px-4 rounded-xl text-white font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md ${
                          jsonError 
                            ? 'bg-slate-300 cursor-not-allowed shadow-none' 
                            : 'bg-primary hover:bg-blue-700 hover:shadow-lg shadow-primary/20'
                        }`}
                      >
                        <i className="fas fa-floppy-disk"></i> Apply & Persist JSON Changes
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default DataEditor;
